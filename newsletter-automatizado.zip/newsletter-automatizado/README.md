# Newsletter Estratégico — Sistema Automatizado

Sistema completo de generación y publicación automática de newsletter ejecutivo diario usando Claude API y GitHub Actions.

## 🎯 ¿Qué hace este sistema?

**Todos los días a las 7:00 AM (hora de Chile):**

1. ✅ Despierta automáticamente
2. 🔍 Claude busca noticias actualizadas de las últimas 24 horas
3. ✍️ Genera un newsletter ejecutivo de 6 secciones
4. 🎨 Crea una página web profesional con el contenido
5. 🌐 Publica automáticamente en tu URL de Netlify
6. 📁 Guarda una copia histórica en el repositorio

**Costo:** US$5–15 al mes (solo por uso de API de Claude)

---

## 📋 Requisitos previos

Antes de comenzar, necesitas tener:

- [x] Cuenta gratuita en **GitHub** → [github.com/signup](https://github.com/signup)
- [x] Cuenta gratuita en **Netlify** → [netlify.com](https://app.netlify.com/signup)
- [x] Cuenta en **Anthropic** con clave API → [console.anthropic.com](https://console.anthropic.com)

---

## 🚀 Instalación paso a paso (30 minutos)

### **Paso 1: Subir este código a GitHub** (5 min)

1. Ve a [github.com/new](https://github.com/new)
2. Nombre del repositorio: `newsletter-estrategico`
3. Marca como **Público** (necesario para GitHub Actions gratuito)
4. Click en **Create repository**

5. Descarga este código a tu computador y súbelo:

```bash
# En tu terminal, dentro de la carpeta descargada:
git init
git add .
git commit -m "Configuración inicial del newsletter automatizado"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/newsletter-estrategico.git
git push -u origin main
```

---

### **Paso 2: Obtener clave API de Anthropic** (3 min)

1. Ve a [console.anthropic.com](https://console.anthropic.com)
2. Click en **API Keys** (menú izquierdo)
3. Click en **Create Key**
4. Dale un nombre: "Newsletter Automatizado"
5. **COPIA LA CLAVE** (empieza con `sk-ant-...`) y guárdala en un lugar seguro

⚠️ **MUY IMPORTANTE:** Esta clave solo se muestra UNA VEZ. Si la pierdes, tendrás que crear otra.

---

### **Paso 3: Configurar Netlify** (5 min)

1. Ve a [app.netlify.com](https://app.netlify.com)
2. Click en **Add new site** → **Import an existing project**
3. Conecta con GitHub y selecciona tu repositorio `newsletter-estrategico`
4. Configuración de build:
   - **Build command:** deja vacío
   - **Publish directory:** `output`
   - Click en **Deploy site**

5. **Obtener credenciales de Netlify:**
   - Una vez desplegado, ve a **Site settings**
   - Copia el **Site ID** (aparece bajo "Site information")
   - Ve a **User settings** → **Applications** → **Personal access tokens**
   - Click en **New access token**
   - Dale un nombre: "Newsletter GitHub Actions"
   - **COPIA EL TOKEN** y guárdalo

---

### **Paso 4: Configurar secretos en GitHub** (5 min)

1. Ve a tu repositorio en GitHub
2. Click en **Settings** → **Secrets and variables** → **Actions**
3. Click en **New repository secret**

Crea estos **3 secretos** uno por uno:

| Nombre | Valor |
|--------|-------|
| `ANTHROPIC_API_KEY` | Tu clave API de Anthropic (sk-ant-...) |
| `NETLIFY_AUTH_TOKEN` | Tu token personal de Netlify |
| `NETLIFY_SITE_ID` | El Site ID de tu sitio en Netlify |

---

### **Paso 5: Probar el sistema** (2 min)

1. En tu repositorio de GitHub, ve a la pestaña **Actions**
2. Click en el workflow **"Generar Newsletter Diario"**
3. Click en **Run workflow** → **Run workflow** (botón verde)
4. Espera 1-2 minutos mientras se ejecuta

✅ **Si todo funcionó:**
- Verás un ✓ verde en el workflow
- En la pestaña **Code**, aparecerá una nueva carpeta `output/` con `index.html`
- Tu sitio de Netlify mostrará el newsletter del día

---

## 🔧 Configuración del horario

El sistema está configurado para ejecutarse **todos los días a las 7:00 AM (hora de Chile)**.

Si quieres cambiar la hora, edita el archivo `.github/workflows/generar-newsletter.yml`:

```yaml
schedule:
  - cron: '0 10 * * *'  # 10:00 UTC = 7:00 AM Chile (UTC-3)
```

**Ejemplos de horarios:**

| Hora deseada (Chile) | Código cron |
|---------------------|-------------|
| 6:00 AM | `'0 9 * * *'` |
| 7:00 AM | `'0 10 * * *'` |
| 8:00 AM | `'0 11 * * *'` |
| 5:00 PM | `'0 20 * * *'` |

---

## 📊 Monitoreo y mantenimiento

### Ver el último newsletter generado
Tu sitio en Netlify: `https://tu-sitio.netlify.app`

### Ver histórico de ediciones
Todas las ediciones se guardan en la carpeta `output/` del repositorio con nombres como:
- `newsletter-2026-05-16.html`
- `newsletter-2026-05-17.html`
- etc.

### Ver si el workflow falló
Ve a la pestaña **Actions** en GitHub. Si un workflow tiene una ❌ roja:
1. Click en el workflow fallido
2. Click en el paso que falló
3. Lee el error (usualmente problemas de API o cuota excedida)

### Ejecutar manualmente
Si quieres generar un newsletter fuera del horario programado:
1. Ve a **Actions** → **Generar Newsletter Diario**
2. **Run workflow** → **Run workflow**

---

## 💰 Costos esperados

| Servicio | Costo |
|----------|-------|
| GitHub Actions | **Gratis** (repos públicos) |
| Netlify Hosting | **Gratis** (hasta 100GB/mes) |
| Claude API | **~US$0.20 por newsletter** |

**Costo mensual total:** US$5–10 (según uso de API)

---

## 🎨 Personalización

### Cambiar el nombre del newsletter
Edita `templates/newsletter-template.html` línea ~305:

```html
El Despacho
<span class="small">Newsletter Estratégico</span>
```

### Modificar los colores
Edita las variables CSS al inicio de `templates/newsletter-template.html`:

```css
:root {
  --accent: #8b1a1a;  /* Color principal */
  --gold: #b8860b;    /* Color dorado */
  --green: #2a5f3f;   /* Verde para indicadores positivos */
}
```

### Ajustar el contenido generado
Edita el `SYSTEM_PROMPT` en `scripts/generar_newsletter.py` (línea 14-70)

---

## 🆘 Solución de problemas

### Error: "ANTHROPIC_API_KEY not found"
- Revisa que el secreto esté configurado correctamente en GitHub
- El nombre debe ser EXACTAMENTE `ANTHROPIC_API_KEY`

### Error: "Rate limit exceeded"
- Has excedido tu cuota de API de Anthropic
- Ve a console.anthropic.com y verifica tu plan/límites
- Considera subir tu límite de gasto mensual

### El newsletter no se publica en Netlify
- Verifica que `NETLIFY_AUTH_TOKEN` y `NETLIFY_SITE_ID` estén correctos
- Ve a Netlify y confirma que el sitio sigue activo

### El contenido generado no es bueno
- El prompt se puede mejorar en `scripts/generar_newsletter.py`
- También puedes ajustar la `temperature` (línea ~190) para más/menos creatividad

---

## 📞 Próximos pasos

Una vez que el sistema esté funcionando:

1. **Conecta un dominio propio** (opcional)
   - En Netlify: Site settings → Domain management
   - Ejemplo: `newsletter.tuempresa.com`

2. **Agrega distribución por email** (recomendado)
   - Considera migrar a Substack o Beehiiv
   - O integra un servicio como SendGrid/Mailchimp

3. **Monetiza tu audiencia**
   - Implementa Stripe para suscripciones de pago
   - O usa Substack que lo trae integrado

---

## 📄 Licencia

Este sistema es de uso libre. Úsalo, modifícalo y mejóralo como necesites.

---

**¿Necesitas ayuda?** Abre un Issue en este repositorio o consulta la documentación de:
- [Anthropic API](https://docs.anthropic.com)
- [GitHub Actions](https://docs.github.com/en/actions)
- [Netlify Docs](https://docs.netlify.com)

# 🚀 Guía Rápida de Inicio (para NO programadores)

Esta guía te llevará paso a paso para tener tu newsletter automático funcionando en 30 minutos, **sin necesidad de saber programar**.

---

## ✅ Checklist antes de empezar

Necesitas crear 3 cuentas gratuitas (toma 10 minutos):

- [ ] Cuenta en **GitHub** → [github.com/signup](https://github.com/signup)
- [ ] Cuenta en **Netlify** → [netlify.com](https://app.netlify.com/signup)
- [ ] Cuenta en **Anthropic** → [console.anthropic.com](https://console.anthropic.com)

⚠️ **IMPORTANTE:** Usa el mismo email para las 3 cuentas para facilitar la gestión.

---

## 📝 Paso 1: Crear tu cuenta de Anthropic y obtener créditos

1. Ve a [console.anthropic.com](https://console.anthropic.com)
2. Click en **Sign Up** y regístrate
3. **Agrega crédito a tu cuenta:**
   - Ve a **Settings** → **Billing**
   - Click en **Add payment method**
   - Agrega una tarjeta de crédito
   - **Establece un límite de gasto:** US$20/mes (para empezar)

4. **Obtener tu clave API:**
   - Ve a **API Keys** (menú lateral izquierdo)
   - Click en **Create Key**
   - Dale el nombre: "Newsletter Automatizado"
   - **COPIA LA CLAVE** (parece algo así: `sk-ant-api03-xxxxxxxxxxx`)
   - ⚠️ **Pégala en un documento de texto** — solo se muestra UNA VEZ

---

## 📝 Paso 2: Descargar y subir el código a GitHub

### Opción A: Usando GitHub Desktop (MÁS FÁCIL, recomendado)

1. **Descarga GitHub Desktop:**
   - Ve a [desktop.github.com](https://desktop.github.com)
   - Descarga e instala

2. **Descarga este proyecto:**
   - Extrae el archivo ZIP que te entregué en una carpeta (ej: `Documentos/newsletter`)

3. **Sube el código a GitHub:**
   - Abre GitHub Desktop
   - **File** → **Add Local Repository**
   - Selecciona la carpeta donde extrajiste el proyecto
   - Click en **Publish repository**
   - Nombre: `newsletter-estrategico`
   - ✅ Desmarca "Keep this code private" (debe ser público para GitHub Actions gratis)
   - Click en **Publish repository**

### Opción B: Subir manualmente vía web

1. Ve a [github.com/new](https://github.com/new)
2. Nombre: `newsletter-estrategico`
3. Marca como **Público**
4. Click en **Create repository**
5. En la nueva página, click en **uploading an existing file**
6. Arrastra TODOS los archivos del proyecto
7. Click en **Commit changes**

---

## 📝 Paso 3: Conectar con Netlify

1. Ve a [app.netlify.com](https://app.netlify.com)
2. Click en **Add new site** → **Import an existing project**
3. Click en **GitHub**
4. Autoriza a Netlify a acceder a tu cuenta de GitHub
5. Selecciona el repositorio `newsletter-estrategico`
6. En la configuración:
   - **Branch to deploy:** `main`
   - **Build command:** déjalo vacío
   - **Publish directory:** escribe `output`
7. Click en **Deploy site**
8. Espera 1 minuto a que se despliegue

9. **Toma nota de tu URL:**
   - Netlify te dará una URL como: `https://algo-random-123456.netlify.app`
   - Puedes cambiarla: **Site settings** → **Change site name**
   - Ejemplo: `el-despacho` → tu URL será `https://el-despacho.netlify.app`

---

## 📝 Paso 4: Obtener credenciales de Netlify

1. Estando en tu sitio de Netlify, ve a **Site settings** (abajo a la izquierda)
2. Busca la sección **Site information**
3. **Copia el "Site ID"** (parece algo así: `abc12345-6789-defg-hijk-lmnopqrstuv`)
4. Pégalo en tu documento de texto

5. Ahora necesitas el token personal:
   - Click en tu avatar (arriba a la derecha) → **User settings**
   - **Applications** → **Personal access tokens**
   - **New access token**
   - Descripción: "GitHub Actions Newsletter"
   - **Generate token**
   - **COPIA EL TOKEN** (empieza con `nfp_...`)
   - Pégalo en tu documento de texto

---

## 📝 Paso 5: Configurar los secretos en GitHub

Ahora vamos a guardar las 3 credenciales de forma segura en GitHub.

1. Ve a tu repositorio en GitHub: `github.com/TU-USUARIO/newsletter-estrategico`
2. Click en **Settings** (última pestaña arriba)
3. En el menú lateral izquierdo: **Secrets and variables** → **Actions**
4. Click en **New repository secret**

Vas a crear **3 secretos**, uno por uno:

### Secreto 1: ANTHROPIC_API_KEY
- **Name:** `ANTHROPIC_API_KEY` (escríbelo EXACTAMENTE así, todo en mayúsculas)
- **Secret:** Pega tu clave API de Anthropic (sk-ant-...)
- Click en **Add secret**

### Secreto 2: NETLIFY_AUTH_TOKEN
- **Name:** `NETLIFY_AUTH_TOKEN`
- **Secret:** Pega tu token personal de Netlify (nfp_...)
- Click en **Add secret**

### Secreto 3: NETLIFY_SITE_ID
- **Name:** `NETLIFY_SITE_ID`
- **Secret:** Pega el Site ID de Netlify (abc12345-...)
- Click en **Add secret**

✅ Deberías ver 3 secretos en la lista ahora.

---

## 🎉 Paso 6: Probar que funciona

1. En tu repositorio de GitHub, ve a la pestaña **Actions**
2. Verás un workflow llamado **"Generar Newsletter Diario"**
3. Click sobre él
4. Click en el botón **Run workflow** (a la derecha)
5. En el menú que aparece, click en el botón verde **Run workflow**

**Espera 2-3 minutos** mientras se ejecuta. Verás:
- Un círculo amarillo girando ⟳ (en proceso)
- Una ✅ verde (funcionó)
- Una ❌ roja (falló)

### ✅ Si salió todo bien:

1. Ve a tu sitio de Netlify: `https://tu-sitio.netlify.app`
2. ¡Deberías ver tu newsletter del día publicado!
3. También puedes ver el archivo en GitHub: ve a la pestaña **Code** → carpeta `output/` → `index.html`

### ❌ Si salió mal:

1. Click en el workflow que falló (la línea con ❌ roja)
2. Click en el trabajo que falló (probablemente "generar-newsletter")
3. Click en el paso que tiene la ❌
4. Lee el error. Los más comunes:

| Error | Solución |
|-------|----------|
| "ANTHROPIC_API_KEY not found" | Revisa que el secreto esté creado EXACTAMENTE como `ANTHROPIC_API_KEY` |
| "Invalid API key" | Tu clave de Anthropic está mal. Verifica que la copiaste completa |
| "Rate limit exceeded" | Has gastado tus créditos de Anthropic. Agrega más en console.anthropic.com |
| "Netlify auth failed" | Tu NETLIFY_AUTH_TOKEN está mal. Crea uno nuevo |

---

## ⏰ Configuración del horario automático

El sistema está configurado para ejecutarse **todos los días a las 7:00 AM (hora de Chile)**.

Si quieres cambiar la hora:

1. En GitHub, ve a tu repositorio
2. Abre el archivo `.github/workflows/generar-newsletter.yml`
3. Click en el lápiz ✏️ para editar
4. Busca la línea que dice:
   ```yaml
   - cron: '0 10 * * *'
   ```
5. Cámbiala según esta tabla:

| Hora que quieres (Chile) | Código |
|--------------------------|--------|
| 6:00 AM | `'0 9 * * *'` |
| 7:00 AM | `'0 10 * * *'` |
| 8:00 AM | `'0 11 * * *'` |
| 12:00 PM (mediodía) | `'0 15 * * *'` |
| 6:00 PM | `'0 21 * * *'` |

6. Click en **Commit changes**

---

## 💡 Preguntas frecuentes

### ¿Cuánto me va a costar esto al mes?
- **GitHub:** Gratis (para repositorios públicos)
- **Netlify:** Gratis (hasta 100GB de ancho de banda/mes)
- **Claude API:** ~US$0.15–0.30 por newsletter × 30 días = **US$5–10/mes**

### ¿Puedo cambiar el nombre "El Despacho"?
Sí. Edita el archivo `templates/newsletter-template.html` y busca las líneas que dicen "El Despacho". Cámbialas por el nombre que quieras.

### ¿Cómo veo el newsletter de días anteriores?
Todos se guardan en GitHub, en la carpeta `output/` con nombres como `newsletter-2026-05-16.html`, `newsletter-2026-05-17.html`, etc.

### ¿Puedo usar mi propio dominio en vez de .netlify.app?
Sí. En Netlify: **Site settings** → **Domain management** → **Add custom domain**. Ejemplo: `newsletter.tuempresa.com`

### Si falla un día, ¿qué pasa?
Puedes ejecutarlo manualmente desde GitHub Actions > Run workflow. O simplemente esperar al día siguiente.

### ¿Cómo agrego suscriptores por email?
Este sistema solo publica en la web. Para enviar por email, considera migrar a [Substack](https://substack.com) o integrar un servicio como SendGrid/Mailchimp.

---

## 🆘 ¿Necesitas ayuda?

Si te trabas en algún paso:

1. Revisa bien esta guía paso a paso
2. Verifica que copiaste las claves correctamente (sin espacios al inicio o final)
3. Busca el error específico en Google: "github actions [tu error]"
4. Abre un Issue en el repositorio de GitHub

---

**¡Listo!** Una vez configurado, tu newsletter se generará y publicará automáticamente cada día. Solo preocúpate de compartirlo con tu audiencia. 🎉
